/**
 * 
 */
/**
 * 
 */
module GestioneHotel {
	requires pdfbox.app;
	requires java.sql;
	requires jdk.httpserver;
}