package Hotel;

public class Admin {

}
