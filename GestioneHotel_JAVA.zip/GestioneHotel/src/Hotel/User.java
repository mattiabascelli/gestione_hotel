package Hotel;

public class User {

}
